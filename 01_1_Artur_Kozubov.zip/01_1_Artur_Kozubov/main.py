

import dpkt
import sys

from utils import *

# Replace this with your protocols file path
protocols_file_path = 'protocols.yaml'

output = {'name': 'PKS2023/24'}
protocols = []


def getProtocol(type, hex_type):
    key = int.from_bytes(hex_type, 'big')
    if key in protocols[type]:
        return protocols[type][key]
    return None


def write(data):
    from ruamel.yaml import YAML
    yaml = YAML()
    yaml.dump(data, sys.stdout)
    with open(data.get('pcap_name').split('.')[0] + '.yaml', 'w') as output_file:
        yaml.dump(data, output_file)


def read_protocols_file(file_path):
    global protocols
    from ruamel.yaml import YAML
    yaml = YAML()
    with open(file_path, 'r') as file:
        protocols = yaml.load(file)


def read_pcap_file(file_path):
    print(file_path)
    with (open(file_path, 'rb') as file):
        output['pcap_name'] = file_path
        pcap = dpkt.pcap.Reader(file)

        output['packets'] = []

        index = 0
        for timestamp, buf in pcap:
            index += 1
            hex_frame = buf
            # noinspection PyDictCreation
            packet = {}

            packet['frame_number'] = index
            packet['len_frame_pcap'] = len(buf)
            packet['len_frame_medium'] = packet['len_frame_pcap'] + 4

            packet['src_mac'] = mac_format(buf[0:6])
            packet['dst_mac'] = mac_format(buf[6:12])

            ether_length = buf[12:14]

            # check on ISL and cut if
            if ' '.join(f'{b:02X}' for b in buf[0:5]) == '01 00 0C 00 00':
                buf = buf[26:]

            if ether_length >= b'\x06x00':
                packet['frame_type'] = 'ETHERNET II'
                buf = buf[14:]
            else:
                if ether_length <= b'\x05\xDC':
                    packet['frame_type'] = 'IEEE 802.3 LLC'
                    packet['sap'] = getProtocol('sap', buf[14:15])

                    if packet['sap'] == 'SNAP':
                        packet['pid'] = getProtocol('pid', buf[20:22])
                else:
                    packet['frame_type'] = 'IEEE 802.3 RAW'

            packet['hexa_frame'] = hex_format(hex_frame)
            output['packets'].append(packet)


try:
    read_protocols_file(protocols_file_path)
    read_pcap_file(sys.argv[1])
    write(output)
except FileNotFoundError:
    print('file cannot be found by specified path')
